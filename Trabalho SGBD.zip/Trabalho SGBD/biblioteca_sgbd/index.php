<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sistema de Biblioteca</title>
    <meta charset="UTF-8">
    <title>Biblioteca</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h1>Sistema de Biblioteca</h1>

<p>Escolha uma opção:</p>

<ul>
    <li style="list-style-type: none;"><a href="usuario/cadastrar_usuario.php">Cadastrar Usuário</a></li>
    <li style="list-style-type: none;"><a href="usuario/listar_usuarios.php">Listar Usuários</a></li>
    <br>
    <li style="list-style-type: none;"><a href="livro/cadastrar_livro.php">Cadastrar Livro</a></li>
    <li style="list-style-type: none;"><a href="livro/listar_livros.php">Listar Livros</a></li>
    <br>
    <li style="list-style-type: none;"><a href="emprestimo/cadastrar_emprestimo.php">Cadastrar Empréstimo</a></li>
    <li style="list-style-type: none;"><a href="emprestimo/listar_emprestimos.php">Listar Empréstimos</a></li>
</ul>

</body>
</html>
